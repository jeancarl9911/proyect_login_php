<?php require_once __DIR__ . '/includes/header.php'; ?>
<h1>Sistema de Login en PHP</h1>
<p>Bienvenido. Usa el menú para navegar.</p>
<?php echo "</main></body></html>"; ?>
